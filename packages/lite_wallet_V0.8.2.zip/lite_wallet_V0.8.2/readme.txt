this program need jdk1.8+;
please run wallet-lite.jar, if cann't start ,please run start.bat